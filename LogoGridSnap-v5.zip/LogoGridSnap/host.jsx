var GRID_LAYER_NAME = "Logo_Guidelines";
$.global.lgsLastSig = "";
$.global.lgsStableCount = 0;

function resetStability() {
  $.global.lgsLastSig = "";
  $.global.lgsStableCount = 0;
}

function getOrCreateGridLayer(doc) {
  for (var i = 0; i < doc.layers.length; i++) {
    if (doc.layers[i].name === GRID_LAYER_NAME) {
      if (doc.layers[i].locked) doc.layers[i].locked = false;
      return doc.layers[i];
    }
  }
  var prevActive = doc.activeLayer;
  var layer = doc.layers.add();
  layer.name = GRID_LAYER_NAME;
  // Restore previous active layer so subsequent shapes are not drawn onto Logo_Guidelines
  try {
    if (prevActive && prevActive !== layer) {
      doc.activeLayer = prevActive;
    }
  } catch (e) {}
  return layer;
}

function collectLogoPaths(doc, excludeItem) {
  var out = [];
  function walkItems(items) {
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (it === excludeItem || it.hidden) continue;
      if (it.typename === "PathItem") {
        if (it.name && it.name.indexOf("guideline_") === 0) continue;
        out.push(it);
      } else if (it.typename === "CompoundPathItem") {
        walkItems(it.pathItems);
      } else if (it.typename === "GroupItem") {
        walkItems(it.pageItems);
      }
    }
  }
  function walkLayer(layer) {
    if (!layer.visible || layer.name === GRID_LAYER_NAME) return;
    walkItems(layer.pageItems);
    for (var s = 0; s < layer.layers.length; s++) {
      walkLayer(layer.layers[s]);
    }
  }
  for (var l = 0; l < doc.layers.length; l++) {
    walkLayer(doc.layers[l]);
  }
  return out;
}

function bezierPoint(p0, p1, p2, p3, t) {
  var mt = 1 - t;
  var x = mt*mt*mt*p0[0] + 3*mt*mt*t*p1[0] + 3*mt*t*t*p2[0] + t*t*t*p3[0];
  var y = mt*mt*mt*p0[1] + 3*mt*mt*t*p1[1] + 3*mt*t*t*p2[1] + t*t*t*p3[1];
  return [x, y];
}

function bezierTangent(p0, p1, p2, p3, t) {
  var mt = 1 - t;
  var dx = 3*mt*mt*(p1[0]-p0[0]) + 6*mt*t*(p2[0]-p1[0]) + 3*t*t*(p3[0]-p2[0]);
  var dy = 3*mt*mt*(p1[1]-p0[1]) + 6*mt*t*(p2[1]-p1[1]) + 3*t*t*(p3[1]-p2[1]);
  return [dx, dy];
}

function isStraightSegment(ptA, ptB) {
  var a = ptA.anchor, ra = ptA.rightDirection;
  var b = ptB.anchor, lb = ptB.leftDirection;
  var d1 = Math.abs(a[0]-ra[0]) + Math.abs(a[1]-ra[1]);
  var d2 = Math.abs(b[0]-lb[0]) + Math.abs(b[1]-lb[1]);
  return (d1 < 0.05 && d2 < 0.05);
}

function isCurvedOval(item) {
  if (!item.closed || item.pathPoints.length !== 4) return false;
  var pts = item.pathPoints;
  for (var i = 0; i < 4; i++) {
    if (!isStraightSegment(pts[i], pts[(i + 1) % 4])) return true;
  }
  return false;
}

function getItemSig(item, isLine) {
  var b = item.geometricBounds;
  var sig = b[0].toFixed(2) + "," + b[1].toFixed(2) + "," + b[2].toFixed(2) + "," + b[3].toFixed(2) + ":" + item.pathPoints.length;
  if (isLine && item.pathPoints.length === 2) {
    var p0 = item.pathPoints[0].anchor;
    var p1 = item.pathPoints[1].anchor;
    sig += ":" + p0[0].toFixed(2) + "," + p0[1].toFixed(2) + "," + p1[0].toFixed(2) + "," + p1[1].toFixed(2);
  }
  return sig;
}

function circumcircle(p1, p2, p3) {
  var ax = p1[0], ay = p1[1];
  var bx = p2[0], by = p2[1];
  var cx = p3[0], cy = p3[1];
  var d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by));
  if (Math.abs(d) < 1e-5) return null;
  var ux = ((ax*ax + ay*ay)*(by - cy) + (bx*bx + by*by)*(cy - ay) + (cx*cx + cy*cy)*(ay - by)) / d;
  var uy = ((ax*ax + ay*ay)*(cx - bx) + (bx*bx + by*by)*(ax - cx) + (cx*cx + cy*cy)*(bx - ax)) / d;
  var r = Math.sqrt((ux - ax)*(ux - ax) + (uy - ay)*(uy - ay));
  return { cx: ux, cy: uy, r: r };
}

function styleGuideline(item, nameTag) {
  item.filled = false;
  item.stroked = true;
  item.strokeWidth = 0.5;
  var grey = new GrayColor();
  grey.gray = 60;
  item.strokeColor = grey;
  item.name = nameTag;
}

function findClosestOnTargets(targets, px, py, curvesOnly) {
  var best = { dist: 1e9, pt: null, tangent: null, isStraight: true, p0: null, p1: null, p2: null, p3: null, t: 0 };
  var steps = 16;

  for (var i = 0; i < targets.length; i++) {
    var pts = targets[i].pathPoints;
    var count = pts.length;
    if (count < 2) continue;
    var segs = targets[i].closed ? count : count - 1;
    for (var j = 0; j < segs; j++) {
      var ptA = pts[j];
      var ptB = pts[(j + 1) % count];
      var straight = isStraightSegment(ptA, ptB);
      if (curvesOnly && straight) continue;

      var p0 = ptA.anchor, p1 = ptA.rightDirection, p2 = ptB.leftDirection, p3 = ptB.anchor;
      for (var s = 0; s <= steps; s++) {
        var t = s / steps;
        var bp = bezierPoint(p0, p1, p2, p3, t);
        var dx = px - bp[0], dy = py - bp[1];
        var d = Math.sqrt(dx*dx + dy*dy);
        if (d < best.dist) {
          best.dist = d;
          best.pt = bp;
          best.tangent = bezierTangent(p0, p1, p2, p3, t);
          best.isStraight = straight;
          best.p0 = p0; best.p1 = p1; best.p2 = p2; best.p3 = p3;
          best.t = t;
        }
      }
    }
  }
  return best;
}

function snapSelectedShape(extendPt, snapRange) {
  try {
    if (!app.documents.length) { resetStability(); return "SKIP"; }
    var doc = app.activeDocument;
    if (!doc.selection || doc.selection.length !== 1) { resetStability(); return "SKIP"; }

    var item = doc.selection[0];
    if (item.typename !== "PathItem") { resetStability(); return "SKIP"; }

    // Never snap end-cap squares
    if (item.name === "guideline_cap") { resetStability(); return "SKIP"; }

    // Only consider 2-point open lines or 4-point closed curved circles/ellipses
    var isLine = (!item.closed && item.pathPoints.length === 2);
    var isOval = isCurvedOval(item);
    if (!isLine && !isOval) { resetStability(); return "SKIP"; }

    var sig = getItemSig(item, isLine);

    // If this is an already-snapped guideline that hasn't moved since snapping, skip it.
    // If the user moved or Alt-dragged it to a new position, its sig won't match item.note, so allow re-snap!
    if (item.name && item.name.indexOf("guideline_") === 0) {
      if (item.note === "lgs:" + sig) {
        resetStability();
        return "SKIP";
      }
    }

    // STABILITY DEBOUNCE: Wait until shape stops changing (user released mouse)
    if (sig !== $.global.lgsLastSig) {
      $.global.lgsLastSig = sig;
      $.global.lgsStableCount = 0;
      return "SKIP";
    }
    $.global.lgsStableCount++;
    if ($.global.lgsStableCount < 2) {
      return "SKIP";
    }

    // Mouse has been released and shape is stable — reset and snap!
    resetStability();

    var targets = collectLogoPaths(doc, item);
    if (!targets.length) return "SKIP";

    var prevActiveLayer = doc.activeLayer;
    var gridLayer = getOrCreateGridLayer(doc);
    var b = item.geometricBounds;

    if (isLine) {
      var lp1 = item.pathPoints[0].anchor;
      var lp2 = item.pathPoints[1].anchor;
      var midX = (lp1[0] + lp2[0]) / 2;
      var midY = (lp1[1] + lp2[1]) / 2;
      var origLen = Math.sqrt((lp2[0]-lp1[0])*(lp2[0]-lp1[0]) + (lp2[1]-lp1[1])*(lp2[1]-lp1[1]));

      var best = findClosestOnTargets(targets, midX, midY, false);
      var c1 = findClosestOnTargets(targets, lp1[0], lp1[1], false);
      if (c1.dist < best.dist) best = c1;
      var c2 = findClosestOnTargets(targets, lp2[0], lp2[1], false);
      if (c2.dist < best.dist) best = c2;
      if (!best.pt || best.dist > snapRange) return "SKIP";

      var newP1, newP2;
      if (best.isStraight) {
        var dx = best.p3[0] - best.p0[0];
        var dy = best.p3[1] - best.p0[1];
        var len = Math.sqrt(dx*dx + dy*dy);
        if (len < 0.01) return "SKIP";
        var ux = dx / len, uy = dy / len;
        newP1 = [best.p0[0] - ux * extendPt, best.p0[1] - uy * extendPt];
        newP2 = [best.p3[0] + ux * extendPt, best.p3[1] + uy * extendPt];
      } else {
        var tx = best.tangent[0], ty = best.tangent[1];
        var tlen = Math.sqrt(tx*tx + ty*ty);
        if (tlen < 0.001) return "SKIP";
        var ux = tx / tlen, uy = ty / tlen;
        var half = Math.max(origLen / 2, 40) + extendPt;
        newP1 = [best.pt[0] - ux * half, best.pt[1] - uy * half];
        newP2 = [best.pt[0] + ux * half, best.pt[1] + uy * half];
      }

      if (item.layer !== gridLayer) {
        item.move(gridLayer, ElementPlacement.PLACEATBEGINNING);
      }
      item.setEntirePath([newP1, newP2]);
      styleGuideline(item, "guideline_line");
      item.note = "lgs:" + getItemSig(item, true);
      try {
        if (prevActiveLayer && prevActiveLayer.name !== GRID_LAYER_NAME) {
          doc.activeLayer = prevActiveLayer;
        }
      } catch (e) {}
      doc.selection = null;
      app.redraw();
      return best.isStraight ? "Snapped line to edge" : "Snapped tangent to curve";
    }

    if (isOval) {
      var w = Math.abs(b[2] - b[0]);
      var h = Math.abs(b[1] - b[3]);
      if (w < 2 || h < 2) return "SKIP";

      var isCircle = (Math.abs(w - h) / Math.max(w, h)) < 0.08;

      if (isCircle) {
        var cx = (b[0] + b[2]) / 2;
        var cy = (b[1] + b[3]) / 2;
        var rad = (w + h) / 4;
        var best = { dist: 1e9, pt: null };
        for (var k = 0; k < 12; k++) {
          var ang = (k * Math.PI * 2) / 12;
          var sx = cx + Math.cos(ang) * rad;
          var sy = cy + Math.sin(ang) * rad;
          var cand = findClosestOnTargets(targets, sx, sy, true);
          if (cand.dist < best.dist) best = cand;
        }
        if (!best.pt || best.dist > snapRange) return "SKIP";

        var tMid = Math.max(0.15, Math.min(0.85, best.t));
        var pA = bezierPoint(best.p0, best.p1, best.p2, best.p3, tMid - 0.12);
        var pB = bezierPoint(best.p0, best.p1, best.p2, best.p3, tMid);
        var pC = bezierPoint(best.p0, best.p1, best.p2, best.p3, tMid + 0.12);
        var circ = circumcircle(pA, pB, pC);
        if (!circ || circ.r > 5000 || circ.r < 2) return "SKIP";

        var top = circ.cy + circ.r;
        var left = circ.cx - circ.r;
        var diam = circ.r * 2;

        var newCircle = gridLayer.pathItems.ellipse(top, left, diam, diam);
        styleGuideline(newCircle, "guideline_circle");
        newCircle.note = "lgs:" + getItemSig(newCircle, false);
        item.remove();
        try {
          if (prevActiveLayer && prevActiveLayer.name !== GRID_LAYER_NAME) {
            doc.activeLayer = prevActiveLayer;
          }
        } catch (e) {}
        doc.selection = null;
        app.redraw();
        return "Snapped circle (r=" + Math.round(circ.r) + "pt)";
      } else {
        var left = b[0], top = b[1], right = b[2], bottom = b[3];
        var ecx = (left + right) / 2;
        var ecy = (top + bottom) / 2;
        var snappedAny = false;

        var topHit = findClosestOnTargets(targets, ecx, top, false);
        if (topHit.pt && topHit.dist <= snapRange) { top = topHit.pt[1]; snappedAny = true; }

        var botHit = findClosestOnTargets(targets, ecx, bottom, false);
        if (botHit.pt && botHit.dist <= snapRange) { bottom = botHit.pt[1]; snappedAny = true; }

        var leftHit = findClosestOnTargets(targets, left, ecy, false);
        if (leftHit.pt && leftHit.dist <= snapRange) { left = leftHit.pt[0]; snappedAny = true; }

        var rightHit = findClosestOnTargets(targets, right, ecy, false);
        if (rightHit.pt && rightHit.dist <= snapRange) { right = rightHit.pt[0]; snappedAny = true; }

        if (!snappedAny) return "SKIP";

        var newW = Math.abs(right - left);
        var newH = Math.abs(top - bottom);
        if (newW < 4 || newH < 4) return "SKIP";

        var newEllipse = gridLayer.pathItems.ellipse(Math.max(top, bottom), Math.min(left, right), newW, newH);
        styleGuideline(newEllipse, "guideline_ellipse");
        newEllipse.note = "lgs:" + getItemSig(newEllipse, false);
        item.remove();
        try {
          if (prevActiveLayer && prevActiveLayer.name !== GRID_LAYER_NAME) {
            doc.activeLayer = prevActiveLayer;
          }
        } catch (e) {}
        doc.selection = null;
        app.redraw();
        return "Snapped ellipse to logo edges";
      }
    }

    return "SKIP";
  } catch (e) {
    resetStability();
    return "SKIP";
  }
}

function applyLineStyle(styleType) {
  var doc = app.activeDocument;
  var layer = getOrCreateGridLayer(doc);
  for (var i = 0; i < layer.pathItems.length; i++) {
    var item = layer.pathItems[i];
    if (item.name === "guideline_cap") continue;
    if (styleType === "solid") item.strokeDashes = [];
    else if (styleType === "dashed") item.strokeDashes = [4, 4];
    else if (styleType === "dotted") item.strokeDashes = [1, 3];
  }
}

function toggleEndCaps(enable) {
  var doc = app.activeDocument;
  var layer = getOrCreateGridLayer(doc);

  for (var i = layer.pathItems.length - 1; i >= 0; i--) {
    if (layer.pathItems[i].name === "guideline_cap") {
      layer.pathItems[i].remove();
    }
  }

  if (!enable) return;

  var size = 3;
  var grey = new GrayColor();
  grey.gray = 60;

  var lines = [];
  for (var j = 0; j < layer.pathItems.length; j++) {
    if (layer.pathItems[j].name === "guideline_line") {
      lines.push(layer.pathItems[j]);
    }
  }

  for (var k = 0; k < lines.length; k++) {
    var pts = lines[k].pathPoints;
    var ends = [pts[0].anchor, pts[pts.length - 1].anchor];
    for (var e = 0; e < ends.length; e++) {
      var cx = ends[e][0], cy = ends[e][1];
      var rect = layer.pathItems.rectangle(cy + size / 2, cx - size / 2, size, size);
      rect.name = "guideline_cap";
      rect.filled = true;
      rect.fillColor = grey;
      rect.stroked = false;
    }
  }
}
