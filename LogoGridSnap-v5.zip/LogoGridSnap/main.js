var autoSnapOn = false;
var pollTimeout = null;
var pollGen = 0;

function runJSX(script, callback) {
  if (window.__adobe_cep__) {
    window.__adobe_cep__.evalScript(script, function (res) {
      if (callback) callback(res);
    });
  }
}

document.getElementById("btnAutoSnap").addEventListener("click", function () {
  autoSnapOn = !autoSnapOn;
  pollGen++;
  var btn = document.getElementById("btnAutoSnap");
  if (pollTimeout) {
    clearTimeout(pollTimeout);
    pollTimeout = null;
  }

  if (autoSnapOn) {
    btn.textContent = "Auto-Snap: ON";
    btn.classList.add("active");
    document.getElementById("status").textContent = "Listening... draw or move & release to snap.";
    var currentGen = pollGen;
    runJSX("resetStability()", function () {
      scheduleNextPoll(currentGen);
    });
  } else {
    btn.textContent = "Auto-Snap: OFF";
    btn.classList.remove("active");
    document.getElementById("status").textContent = "Auto-Snap paused.";
    runJSX("resetStability()");
  }
});

function scheduleNextPoll(gen) {
  if (!autoSnapOn || gen !== pollGen) return;
  pollTimeout = setTimeout(function () {
    if (!autoSnapOn || gen !== pollGen) return;
    var ext = parseFloat(document.getElementById("extendVal").value) || 0;
    var range = parseFloat(document.getElementById("snapRange").value) || 60;

    runJSX("snapSelectedShape(" + ext + ", " + range + ")", function (res) {
      if (!autoSnapOn || gen !== pollGen) return;
      if (res && res !== "SKIP" && res !== "" && res !== "EvalScript error.") {
        document.getElementById("status").textContent = res;
      }
      scheduleNextPoll(gen);
    });
  }, 200);
}

function setStyle(type) {
  runJSX("applyLineStyle('" + type + "')");
}

function toggleCaps(enable) {
  runJSX("toggleEndCaps(" + enable + ")");
}
